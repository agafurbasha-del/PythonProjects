from django.db import models

class StudentDetails(models.Model):
    sId = models.IntegerField()
    sName = models.CharField(max_length=25)
    phone = models.CharField(max_length=25)
    email = models.CharField(max_length=25)
    branch = models.CharField(max_length=25)
    section = models.CharField(max_length=25)
    address = models.CharField(max_length=25)
    j_marks = models.FloatField()
    dn_marks = models.FloatField()
    wd_marks = models.FloatField()
    db_marks = models.FloatField()
    p_marks = models.FloatField()