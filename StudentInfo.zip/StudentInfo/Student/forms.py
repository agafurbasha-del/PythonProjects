from django import forms
from .models import StudentDetails

class StudentDetailsForm(forms.ModelForm):
    class Meta:
        model = StudentDetails
        fields = ['sId', 'sName', 'phone', 'email', 'branch', 'section', 'address', 'j_marks', 'dn_marks', 'wd_marks', 'db_marks', 'p_marks']

        widgets = {
            'sId': forms.NumberInput(attrs={'class': 'form-control'}),
            'sName': forms.TextInput(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'branch': forms.TextInput(attrs={'class': 'form-control'}),
            'section': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'j_marks': forms.NumberInput(attrs={'class': 'form-control'}),
            'dn_marks': forms.NumberInput(attrs={'class': 'form-control'}),
            'wd_marks': forms.NumberInput(attrs={'class': 'form-control'}),
            'db_marks': forms.NumberInput(attrs={'class': 'form-control'}),
            'p_marks': forms.NumberInput(attrs={'class': 'form-control'}),
        }