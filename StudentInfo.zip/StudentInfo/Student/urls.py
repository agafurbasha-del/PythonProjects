from django.urls import path
from .views import show, fulldetails, addstudent, updatestudent, deletestudent

urlpatterns = [
    path('', show, name='home'),
    path('fulldetails<int:pk>', fulldetails, name='fulldetails'),
    path('addstudent', addstudent, name='addstudent'),
    path('updatestudent/<int:pk>', updatestudent, name='updatestudent'),
    path('deletestudent/<int:pk>', deletestudent, name='deletestudent')
]