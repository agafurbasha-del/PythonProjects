from django.shortcuts import render, redirect
from .models import StudentDetails
from .forms import StudentDetailsForm
def show(request):
    data = StudentDetails.objects.all()
    return render(request, 'show.html', {'data' : data})

def fulldetails(request, pk):
    student = StudentDetails.objects.get(id=pk)
    return render(request, 'fulldetails.html', {'student': student})

def addstudent(request):
    if request.method == 'POST':
        form = StudentDetailsForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    form = StudentDetailsForm()
    return render(request, 'add.html', {'form' : form})

def updatestudent(request, pk):
    data = StudentDetails.objects.get(id=pk)
    if request.method == 'POST':
        form = StudentDetailsForm(request.POST, request.FILES, instance=data)
        if form.is_valid():
            form.save()
            return redirect('home')
    form = StudentDetailsForm(instance=data)
    return render(request, 'update.html', {'form' : form})

def deletestudent(request, pk):
    data = StudentDetails.objects.get(id=pk)
    data.delete()
    return redirect('home')