from django.contrib import admin
from .models import StudentDetails
class StudentDetailsAdmin(admin.ModelAdmin):
    list_display = ['sId', 'sName', 'phone', 'email', 'branch', 'section', 'address', 'j_marks', 'dn_marks', 'wd_marks', 'db_marks', 'p_marks']
admin.site.register(StudentDetails, StudentDetailsAdmin)